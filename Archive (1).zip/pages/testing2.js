import React from 'react'

const testing2 = () => {
  return (
    <div>testing2</div>
  )
}

export default testing2