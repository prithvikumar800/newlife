import React from 'react'

const createemployee = () => {
  return (
    <div>createemployee</div>
  )
}

export default createemployee