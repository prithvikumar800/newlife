import React from 'react'

const Data = () => {
  return (
    <div>Data</div>
  )
}

export default Data